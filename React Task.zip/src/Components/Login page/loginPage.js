import React,{useState} from 'react';
import './loginPage.css'
import Field from '../../Shared/input';

const Login = (params) => {
   const [login,setlogin] = useState(true);

    return (
        <div>
            <form>
             <h1> {login ? "Log in!" :"Sign up"}</h1>
             {login ? null:<Field name="Username" fieldType="text" holder="Enter Name"/> }
                <Field name="Email" fieldType="email" holder="Enter Name"/>
                <Field name="Password" fieldType="password" holder="Enter Password"/>
                <button class="button button2">{login ?"Log in":"Sign Up"}</button>
            </form>
            <button onClick={ () => {setlogin( prev => !prev );} }
            style={{color: "white",}}
            >{login ? "Create New Account" : "Already have an account"}</button>
        </div>
    );
}

export default Login;