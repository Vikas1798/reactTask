import React from 'react';
import './input.css';

const input = (props) => {
    return(
            <fieldset>
                      <legend align="center">{props.name}</legend>
                        <input type={props.fieldType} placeholder={props.holder}/>
                </fieldset>
    );
}

export default input;